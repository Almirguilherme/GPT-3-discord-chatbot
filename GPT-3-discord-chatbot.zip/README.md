# Discord Chatbot using GPT-3

Follow the tutorial here: https://youtu.be/hkMWVrhGorI
